globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/759761ff115bcfc5.js",
    "static/chunks/f091501564eb2ea3.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/10cbf02e6fc36465.js",
    "static/chunks/turbopack-09020beb79c9f6e4.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];