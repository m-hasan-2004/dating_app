module.exports=[8836,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_candidates_%5Bid%5D_page_actions_2ac25a6d.js.map