module.exports=[62511,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_profile_bookmarks_page_actions_40252ec3.js.map