module.exports=[42347,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_search_page_actions_f3eebee6.js.map