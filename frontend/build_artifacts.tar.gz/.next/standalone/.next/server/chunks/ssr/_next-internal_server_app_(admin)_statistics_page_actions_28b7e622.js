module.exports=[40170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_statistics_page_actions_28b7e622.js.map