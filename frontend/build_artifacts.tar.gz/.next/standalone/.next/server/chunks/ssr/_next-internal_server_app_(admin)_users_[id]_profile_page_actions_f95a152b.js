module.exports=[99905,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_users_%5Bid%5D_profile_page_actions_f95a152b.js.map