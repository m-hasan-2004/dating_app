module.exports=[48018,a=>{a.v({className:"outfit_43d50961-module__KOAtAG__className"})},14616,a=>{"use strict";a.s(["SidebarProvider",()=>c,"useSidebar",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call SidebarProvider() from the server but SidebarProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/SidebarContext.tsx <module evaluation>","SidebarProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useSidebar() from the server but useSidebar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/SidebarContext.tsx <module evaluation>","useSidebar")},67487,a=>{"use strict";a.s(["SidebarProvider",()=>c,"useSidebar",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call SidebarProvider() from the server but SidebarProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/SidebarContext.tsx","SidebarProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useSidebar() from the server but useSidebar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/SidebarContext.tsx","useSidebar")},58251,a=>{"use strict";a.i(14616);var b=a.i(67487);a.n(b)},99552,a=>{"use strict";a.s(["ThemeProvider",()=>c,"useTheme",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call ThemeProvider() from the server but ThemeProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/ThemeContext.tsx <module evaluation>","ThemeProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useTheme() from the server but useTheme is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/ThemeContext.tsx <module evaluation>","useTheme")},99624,a=>{"use strict";a.s(["ThemeProvider",()=>c,"useTheme",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call ThemeProvider() from the server but ThemeProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/ThemeContext.tsx","ThemeProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useTheme() from the server but useTheme is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/ThemeContext.tsx","useTheme")},48443,a=>{"use strict";a.i(99552);var b=a.i(99624);a.n(b)},11348,a=>{"use strict";a.s(["AuthProvider",()=>c,"useAuth",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call AuthProvider() from the server but AuthProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/hooks/use-auth.tsx <module evaluation>","AuthProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useAuth() from the server but useAuth is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/hooks/use-auth.tsx <module evaluation>","useAuth")},79126,a=>{"use strict";a.s(["AuthProvider",()=>c,"useAuth",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call AuthProvider() from the server but AuthProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/hooks/use-auth.tsx","AuthProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useAuth() from the server but useAuth is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/hooks/use-auth.tsx","useAuth")},89951,a=>{"use strict";a.i(11348);var b=a.i(79126);a.n(b)},95431,a=>{"use strict";a.s(["LanguageProvider",()=>c,"useLanguage",()=>d,"useTranslation",()=>e]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call LanguageProvider() from the server but LanguageProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/LanguageContext.tsx <module evaluation>","LanguageProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useLanguage() from the server but useLanguage is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/LanguageContext.tsx <module evaluation>","useLanguage"),e=(0,b.registerClientReference)(function(){throw Error("Attempted to call useTranslation() from the server but useTranslation is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/LanguageContext.tsx <module evaluation>","useTranslation")},87469,a=>{"use strict";a.s(["LanguageProvider",()=>c,"useLanguage",()=>d,"useTranslation",()=>e]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call LanguageProvider() from the server but LanguageProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/LanguageContext.tsx","LanguageProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call useLanguage() from the server but useLanguage is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/LanguageContext.tsx","useLanguage"),e=(0,b.registerClientReference)(function(){throw Error("Attempted to call useTranslation() from the server but useTranslation is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/LanguageContext.tsx","useTranslation")},70843,a=>{"use strict";a.i(95431);var b=a.i(87469);a.n(b)},89770,a=>{"use strict";a.s(["BrandingProvider",()=>c,"generatePaletteFromHex",()=>d,"resolveMediaUrl",()=>e,"useBranding",()=>f]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call BrandingProvider() from the server but BrandingProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx <module evaluation>","BrandingProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call generatePaletteFromHex() from the server but generatePaletteFromHex is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx <module evaluation>","generatePaletteFromHex"),e=(0,b.registerClientReference)(function(){throw Error("Attempted to call resolveMediaUrl() from the server but resolveMediaUrl is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx <module evaluation>","resolveMediaUrl"),f=(0,b.registerClientReference)(function(){throw Error("Attempted to call useBranding() from the server but useBranding is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx <module evaluation>","useBranding")},29981,a=>{"use strict";a.s(["BrandingProvider",()=>c,"generatePaletteFromHex",()=>d,"resolveMediaUrl",()=>e,"useBranding",()=>f]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call BrandingProvider() from the server but BrandingProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx","BrandingProvider"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call generatePaletteFromHex() from the server but generatePaletteFromHex is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx","generatePaletteFromHex"),e=(0,b.registerClientReference)(function(){throw Error("Attempted to call resolveMediaUrl() from the server but resolveMediaUrl is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx","resolveMediaUrl"),f=(0,b.registerClientReference)(function(){throw Error("Attempted to call useBranding() from the server but useBranding is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/context/BrandingContext.tsx","useBranding")},59446,a=>{"use strict";a.i(89770);var b=a.i(29981);a.n(b)},75408,a=>{"use strict";a.s(["LanguageToggleButton",()=>c,"default",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call LanguageToggleButton() from the server but LanguageToggleButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/common/LanguageToggleButton.tsx <module evaluation>","LanguageToggleButton"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/common/LanguageToggleButton.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/common/LanguageToggleButton.tsx <module evaluation>","default")},20549,a=>{"use strict";a.s(["LanguageToggleButton",()=>c,"default",()=>d]);var b=a.i(11857);let c=(0,b.registerClientReference)(function(){throw Error("Attempted to call LanguageToggleButton() from the server but LanguageToggleButton is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/common/LanguageToggleButton.tsx","LanguageToggleButton"),d=(0,b.registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/common/LanguageToggleButton.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/common/LanguageToggleButton.tsx","default")},94741,a=>{"use strict";a.i(75408);var b=a.i(20549);a.n(b)},96960,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/common/DynamicPageTitle.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/common/DynamicPageTitle.tsx <module evaluation>","default")},44380,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/common/DynamicPageTitle.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/common/DynamicPageTitle.tsx","default")},55992,a=>{"use strict";a.i(96960);var b=a.i(44380);a.n(b)},27572,a=>{"use strict";var b=a.i(7997),c=a.i(48018);let d={className:c.default.className,style:{fontFamily:"'Outfit', 'Outfit Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(58251),f=a.i(48443),g=a.i(89951),h=a.i(70843),i=a.i(59446),j=a.i(94741),k=a.i(55992);function l({children:a}){return(0,b.jsxs)("html",{lang:"fa",dir:"rtl",suppressHydrationWarning:!0,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`(function(){
  try {
    var r = document.documentElement;

    // 1. Dark Mode initialization
    var savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      r.classList.add('dark');
    } else {
      r.classList.remove('dark');
    }

    // 2. Color Palette & Primary/Accent Color resolution
    var PRESETS = {
      default: { primary: '#465fff', accent: '#3641f5' },
      emerald: { primary: '#10b981', accent: '#059669' },
      purple: { primary: '#8b5cf6', accent: '#7c3aed' },
      rose: { primary: '#f43f5e', accent: '#e11d48' },
      amber: { primary: '#f59e0b', accent: '#d97706' },
      indigo: { primary: '#6366f1', accent: '#4f46e5' },
    };

    var cachedPalette = localStorage.getItem('branding_color_palette') || 'custom';
    var cachedPrimary = localStorage.getItem('branding_custom_primary');
    var cachedSecondary = localStorage.getItem('branding_custom_secondary');

    var primaryColor = cachedPrimary || (PRESETS[cachedPalette] ? PRESETS[cachedPalette].primary : '#289333');
    var accentColor = cachedSecondary || (PRESETS[cachedPalette] ? PRESETS[cachedPalette].accent : primaryColor);

    function hexToRgb(hex) {
      if (!hex || typeof hex !== 'string') return null;
      var c = hex.replace('#', '').trim();
      if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
      if (c.length === 6) {
        return [parseInt(c.substring(0, 2), 16), parseInt(c.substring(2, 4), 16), parseInt(c.substring(4, 6), 16)];
      }
      return null;
    }

    function generateShades(hex) {
      var rgb = hexToRgb(hex);
      if (!rgb) return null;
      var rVal = rgb[0] / 255, gVal = rgb[1] / 255, bVal = rgb[2] / 255;
      var max = Math.max(rVal, gVal, bVal), min = Math.min(rVal, gVal, bVal);
      var h = 0, s = 0, l = (max + min) / 2;
      if (max !== min) {
        var d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case rVal: h = (gVal - bVal) / d + (gVal < bVal ? 6 : 0); break;
          case gVal: h = (bVal - rVal) / d + 2; break;
          case bVal: h = (rVal - gVal) / d + 4; break;
        }
        h /= 6;
      }
      var hDeg = Math.round(h * 360), sPct = Math.round(s * 100);
      function hslToHex(hue, sat, lum) {
        lum /= 100;
        var a = (sat * Math.min(lum, 1 - lum)) / 100;
        var f = function(n) {
          var k = (n + hue / 30) % 12;
          var color = lum - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
          return Math.round(255 * color).toString(16).padStart(2, '0');
        };
        return '#' + f(0) + f(8) + f(4);
      }
      return {
        '25': hslToHex(hDeg, Math.min(sPct, 95), 98),
        '50': hslToHex(hDeg, Math.min(sPct, 95), 96),
        '100': hslToHex(hDeg, Math.min(sPct, 90), 91),
        '200': hslToHex(hDeg, Math.min(sPct, 85), 82),
        '300': hslToHex(hDeg, Math.min(sPct, 80), 71),
        '400': hslToHex(hDeg, Math.min(sPct, 75), 60),
        '500': hex,
        '600': hslToHex(hDeg, Math.min(sPct + 5, 100), 44),
        '700': hslToHex(hDeg, Math.min(sPct + 10, 100), 35),
        '800': hslToHex(hDeg, Math.min(sPct + 10, 100), 27),
        '900': hslToHex(hDeg, Math.min(sPct + 10, 100), 20),
        '950': hslToHex(hDeg, Math.min(sPct + 15, 100), 12),
      };
    }

    var shades = generateShades(primaryColor);
    if (shades) {
      Object.keys(shades).forEach(function(k) {
        r.style.setProperty('--color-brand-' + k, shades[k]);
      });
    }

    var rgb = hexToRgb(primaryColor);
    r.style.setProperty('--color-primary', primaryColor);
    if (rgb) r.style.setProperty('--color-primary-rgb', rgb.join(','));
    r.style.setProperty('--color-accent', accentColor);

    // 3. Canvas light & dark background colors
    var cLight = localStorage.getItem('branding_canvas_light') || '#f8fafc';
    var cDark = localStorage.getItem('branding_canvas_dark') || '#131127';
    r.style.setProperty('--color-canvas-light', cLight);
    r.style.setProperty('--color-canvas-dark', cDark);

    // 4. Custom font
    var cFont = localStorage.getItem('branding_font_family') || 'Vazirmatn';
    r.style.setProperty('--font-active', "'" + cFont + "', var(--font-outfit), Vazirmatn, Tahoma, sans-serif");
  } catch (e) {}
})();`}})}),(0,b.jsx)("body",{className:`${d.className} text-slate-800 dark:text-gray-100 min-h-screen`,suppressHydrationWarning:!0,children:(0,b.jsx)(h.LanguageProvider,{children:(0,b.jsx)(i.BrandingProvider,{children:(0,b.jsx)(f.ThemeProvider,{children:(0,b.jsx)(g.AuthProvider,{children:(0,b.jsxs)(e.SidebarProvider,{children:[(0,b.jsx)(k.default,{}),a,(0,b.jsx)(j.LanguageToggleButton,{})]})})})})})})]})}a.s(["default",()=>l,"metadata",0,{title:{template:"%s | امین وصال",default:"امین وصال"},description:"مرکز همسان‌گزینی و ازدواج دائم امین وصال قم",icons:{icon:"/media/site_branding/favicons/favicon.png",shortcut:"/media/site_branding/favicons/favicon.png",apple:"/media/site_branding/favicons/favicon.png"}}],27572)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__c77526dd._.js.map