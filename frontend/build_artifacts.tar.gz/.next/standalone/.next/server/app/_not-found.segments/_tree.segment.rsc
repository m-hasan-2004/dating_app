:HL["/_next/static/chunks/701bfd7f976a1a7d.css","style"]
:HL["/_next/static/chunks/9506e893e1cc9117.css","style"]
:HL["/_next/static/chunks/0781faae427c77ef.css","style"]
0:{"buildId":"L6SxtE3YhqegVhZ12JYMn","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
