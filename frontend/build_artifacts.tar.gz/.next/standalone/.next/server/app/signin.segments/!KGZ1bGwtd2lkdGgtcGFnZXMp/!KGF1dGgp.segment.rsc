1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ClientSegmentRoot"]
3:I[82317,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/04cbb6eb9e1f2957.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"L6SxtE3YhqegVhZ12JYMn","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/04cbb6eb9e1f2957.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:{}
