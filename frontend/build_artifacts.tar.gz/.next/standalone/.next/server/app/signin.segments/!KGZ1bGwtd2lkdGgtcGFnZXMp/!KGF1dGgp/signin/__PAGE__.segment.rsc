1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[96984,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/04cbb6eb9e1f2957.js","/_next/static/chunks/df89af08f39a668e.js","/_next/static/chunks/4873ff0d8eb7464c.js"],"default"]
4:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
0:{"buildId":"L6SxtE3YhqegVhZ12JYMn","rsc":["$","$1","c",{"children":[["$","$2",null,{"fallback":null,"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/df89af08f39a668e.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/4873ff0d8eb7464c.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
