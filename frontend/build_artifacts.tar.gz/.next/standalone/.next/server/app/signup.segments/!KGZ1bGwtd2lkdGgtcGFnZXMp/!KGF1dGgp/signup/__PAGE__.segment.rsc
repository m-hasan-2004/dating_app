1:"$Sreact.fragment"
2:I[89762,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/04cbb6eb9e1f2957.js","/_next/static/chunks/df89af08f39a668e.js","/_next/static/chunks/9320deba045ce035.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"L6SxtE3YhqegVhZ12JYMn","rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/df89af08f39a668e.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/9320deba045ce035.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
