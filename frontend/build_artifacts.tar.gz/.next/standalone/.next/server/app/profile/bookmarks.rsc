1:"$Sreact.fragment"
9:I[68027,[],"default"]
:HL["/_next/static/chunks/701bfd7f976a1a7d.css","style"]
:HL["/_next/static/chunks/9506e893e1cc9117.css","style"]
:HL["/_next/static/chunks/0781faae427c77ef.css","style"]
:HL["/_next/static/media/1b99372b3eaef0c8-s.p.758e15a8.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:T1118,(function(){
  try {
    var r = document.documentElement;

    // 1. Dark Mode initialization
    var savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      r.classList.add('dark');
    } else {
      r.classList.remove('dark');
    }

    // 2. Color Palette & Primary/Accent Color resolution
    var PRESETS = {
      default: { primary: '#465fff', accent: '#3641f5' },
      emerald: { primary: '#10b981', accent: '#059669' },
      purple: { primary: '#8b5cf6', accent: '#7c3aed' },
      rose: { primary: '#f43f5e', accent: '#e11d48' },
      amber: { primary: '#f59e0b', accent: '#d97706' },
      indigo: { primary: '#6366f1', accent: '#4f46e5' },
    };

    var cachedPalette = localStorage.getItem('branding_color_palette') || 'custom';
    var cachedPrimary = localStorage.getItem('branding_custom_primary');
    var cachedSecondary = localStorage.getItem('branding_custom_secondary');

    var primaryColor = cachedPrimary || (PRESETS[cachedPalette] ? PRESETS[cachedPalette].primary : '#289333');
    var accentColor = cachedSecondary || (PRESETS[cachedPalette] ? PRESETS[cachedPalette].accent : primaryColor);

    function hexToRgb(hex) {
      if (!hex || typeof hex !== 'string') return null;
      var c = hex.replace('#', '').trim();
      if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
      if (c.length === 6) {
        return [parseInt(c.substring(0, 2), 16), parseInt(c.substring(2, 4), 16), parseInt(c.substring(4, 6), 16)];
      }
      return null;
    }

    function generateShades(hex) {
      var rgb = hexToRgb(hex);
      if (!rgb) return null;
      var rVal = rgb[0] / 255, gVal = rgb[1] / 255, bVal = rgb[2] / 255;
      var max = Math.max(rVal, gVal, bVal), min = Math.min(rVal, gVal, bVal);
      var h = 0, s = 0, l = (max + min) / 2;
      if (max !== min) {
        var d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case rVal: h = (gVal - bVal) / d + (gVal < bVal ? 6 : 0); break;
          case gVal: h = (bVal - rVal) / d + 2; break;
          case bVal: h = (rVal - gVal) / d + 4; break;
        }
        h /= 6;
      }
      var hDeg = Math.round(h * 360), sPct = Math.round(s * 100);
      function hslToHex(hue, sat, lum) {
        lum /= 100;
        var a = (sat * Math.min(lum, 1 - lum)) / 100;
        var f = function(n) {
          var k = (n + hue / 30) % 12;
          var color = lum - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
          return Math.round(255 * color).toString(16).padStart(2, '0');
        };
        return '#' + f(0) + f(8) + f(4);
      }
      return {
        '25': hslToHex(hDeg, Math.min(sPct, 95), 98),
        '50': hslToHex(hDeg, Math.min(sPct, 95), 96),
        '100': hslToHex(hDeg, Math.min(sPct, 90), 91),
        '200': hslToHex(hDeg, Math.min(sPct, 85), 82),
        '300': hslToHex(hDeg, Math.min(sPct, 80), 71),
        '400': hslToHex(hDeg, Math.min(sPct, 75), 60),
        '500': hex,
        '600': hslToHex(hDeg, Math.min(sPct + 5, 100), 44),
        '700': hslToHex(hDeg, Math.min(sPct + 10, 100), 35),
        '800': hslToHex(hDeg, Math.min(sPct + 10, 100), 27),
        '900': hslToHex(hDeg, Math.min(sPct + 10, 100), 20),
        '950': hslToHex(hDeg, Math.min(sPct + 15, 100), 12),
      };
    }

    var shades = generateShades(primaryColor);
    if (shades) {
      Object.keys(shades).forEach(function(k) {
        r.style.setProperty('--color-brand-' + k, shades[k]);
      });
    }

    var rgb = hexToRgb(primaryColor);
    r.style.setProperty('--color-primary', primaryColor);
    if (rgb) r.style.setProperty('--color-primary-rgb', rgb.join(','));
    r.style.setProperty('--color-accent', accentColor);

    // 3. Canvas light & dark background colors
    var cLight = localStorage.getItem('branding_canvas_light') || '#f8fafc';
    var cDark = localStorage.getItem('branding_canvas_dark') || '#131127';
    r.style.setProperty('--color-canvas-light', cLight);
    r.style.setProperty('--color-canvas-dark', cDark);

    // 4. Custom font
    var cFont = localStorage.getItem('branding_font_family') || 'Vazirmatn';
    r.style.setProperty('--font-active', "'" + cFont + "', var(--font-outfit), Vazirmatn, Tahoma, sans-serif");
  } catch (e) {}
})();0:{"P":null,"b":"L6SxtE3YhqegVhZ12JYMn","c":["","profile","bookmarks"],"q":"","i":false,"f":[[["",{"children":["(admin)",{"children":["profile",{"children":["bookmarks",{"children":["__PAGE__",{}]}]}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/701bfd7f976a1a7d.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/9506e893e1cc9117.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/chunks/0781faae427c77ef.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/876ef404b65a90b7.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/c36f02d122d45be2.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"fa","dir":"rtl","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],{"children":["$L4",{"children":["$L5",{"children":["$L6",{"children":["$L7",{},null,false,false]},null,false,false]},null,false,false]},null,false,false]},null,false,false],"$L8",false]],"m":"$undefined","G":["$9",[]],"S":true}
a:I[83773,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"LanguageProvider"]
b:I[45993,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"BrandingProvider"]
c:I[9876,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"ThemeProvider"]
d:I[70689,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"AuthProvider"]
e:I[46208,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"SidebarProvider"]
f:I[44941,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"default"]
10:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
11:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
12:I[5500,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/b4872826d9ffb447.js"],"Image"]
13:I[22016,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/b4872826d9ffb447.js"],""]
14:I[72995,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"LanguageToggleButton"]
15:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ClientSegmentRoot"]
16:I[31926,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/8f6df9cd6e506907.js","/_next/static/chunks/8103a4fa4df1e2dd.js"],"default"]
18:I[47257,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ClientPageRoot"]
19:I[51427,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/8f6df9cd6e506907.js","/_next/static/chunks/8103a4fa4df1e2dd.js","/_next/static/chunks/48426c6756882047.js"],"default"]
1c:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
1d:"$Sreact.suspense"
1f:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ViewportBoundary"]
21:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"MetadataBoundary"]
3:["$","body",null,{"className":"outfit_43d50961-module__KOAtAG__className text-slate-800 dark:text-gray-100 min-h-screen","suppressHydrationWarning":true,"children":["$","$La",null,{"children":["$","$Lb",null,{"children":["$","$Lc",null,{"children":["$","$Ld",null,{"children":["$","$Le",null,{"children":[["$","$Lf",null,{}],["$","$L10",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"relative flex flex-col items-center justify-center min-h-screen p-6 overflow-hidden z-1","children":[[["$","div",null,{"className":"absolute right-0 top-0 -z-1 w-full max-w-[250px] xl:max-w-[450px]","children":["$","$L12",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}],["$","div",null,{"className":"absolute bottom-0 left-0 -z-1 w-full max-w-[250px] rotate-180 xl:max-w-[450px]","children":["$","$L12",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}]],["$","div",null,{"className":"mx-auto w-full max-w-[242px] text-center sm:max-w-[472px]","children":[["$","h1",null,{"className":"mb-8 font-bold text-gray-800 text-title-md dark:text-white/90 xl:text-title-2xl","children":"ERROR"}],["$","$L12",null,{"src":"/images/error/404.svg","alt":"404","className":"dark:hidden","width":472,"height":152}],["$","$L12",null,{"src":"/images/error/404-dark.svg","alt":"404","className":"hidden dark:block","width":472,"height":152}],["$","p",null,{"className":"mt-10 mb-6 text-base text-gray-700 dark:text-gray-400 sm:text-lg","children":"We can’t seem to find the page you are looking for!"}],["$","$L13",null,{"href":"/","className":"inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-5 py-3.5 text-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200","children":"Back to Home Page"}]]}],["$","p",null,{"className":"absolute text-sm text-center text-gray-500 -translate-x-1/2 bottom-6 left-1/2 dark:text-gray-400","children":["© ",2026," - امین وصال"]}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L14",null,{}]]}]}]}]}]}]}]
4:["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/8f6df9cd6e506907.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/8103a4fa4df1e2dd.js","async":true,"nonce":"$undefined"}]],["$","$L15",null,{"Component":"$16","slots":{"children":["$","$L10",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"relative flex flex-col items-center justify-center min-h-screen p-6 overflow-hidden z-1","children":[[["$","div",null,{"className":"absolute right-0 top-0 -z-1 w-full max-w-[250px] xl:max-w-[450px]","children":["$","$L12",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}],["$","div",null,{"className":"absolute bottom-0 left-0 -z-1 w-full max-w-[250px] rotate-180 xl:max-w-[450px]","children":["$","$L12",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}]],["$","div",null,{"className":"mx-auto w-full max-w-[242px] text-center sm:max-w-[472px]","children":[["$","h1",null,{"className":"mb-8 font-bold text-gray-800 text-title-md dark:text-white/90 xl:text-title-2xl","children":"ERROR"}],["$","$L12",null,{"src":"/images/error/404.svg","alt":"404","className":"dark:hidden","width":472,"height":152}],["$","$L12",null,{"src":"/images/error/404-dark.svg","alt":"404","className":"hidden dark:block","width":472,"height":152}],["$","p",null,{"className":"mt-10 mb-6 text-base text-gray-700 dark:text-gray-400 sm:text-lg","children":"We can’t seem to find the page you are looking for!"}],["$","$L13",null,{"href":"/","className":"inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-5 py-3.5 text-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200","children":"Back to Home Page"}]]}],["$","p",null,{"className":"absolute text-sm text-center text-gray-500 -translate-x-1/2 bottom-6 left-1/2 dark:text-gray-400","children":["© ",2026," - امین وصال"]}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]},"serverProvidedParams":{"params":{},"promises":["$@17"]}}]]}]
5:["$","$1","c",{"children":[null,["$","$L10",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
6:["$","$1","c",{"children":[null,["$","$L10",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L11",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
7:["$","$1","c",{"children":[["$","$L18",null,{"Component":"$19","serverProvidedParams":{"searchParams":{},"params":"$4:props:children:1:props:serverProvidedParams:params","promises":["$@1a","$@1b"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/48426c6756882047.js","async":true,"nonce":"$undefined"}]],["$","$L1c",null,{"children":["$","$1d",null,{"name":"Next.MetadataOutlet","children":"$@1e"}]}]]}]
8:["$","$1","h",{"children":[null,["$","$L1f",null,{"children":"$L20"}],["$","div",null,{"hidden":true,"children":["$","$L21",null,{"children":["$","$1d",null,{"name":"Next.Metadata","children":"$L22"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
17:"$4:props:children:1:props:serverProvidedParams:params"
1a:{}
1b:"$4:props:children:1:props:serverProvidedParams:params"
20:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
23:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"IconMark"]
1e:null
22:[["$","title","0",{"children":"امین وصال"}],["$","meta","1",{"name":"description","content":"مرکز همسان‌گزینی و ازدواج دائم امین وصال قم"}],["$","link","2",{"rel":"shortcut icon","href":"/media/site_branding/favicons/favicon.png"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?favicon.ba4b60c1.ico","sizes":"640x640","type":"image/x-icon"}],["$","link","4",{"rel":"icon","href":"/media/site_branding/favicons/favicon.png"}],["$","link","5",{"rel":"apple-touch-icon","href":"/media/site_branding/favicons/favicon.png"}],["$","$L23","6",{}]]
