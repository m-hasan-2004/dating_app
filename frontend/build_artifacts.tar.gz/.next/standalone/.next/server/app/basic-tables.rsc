1:"$Sreact.fragment"
a:I[68027,[],"default"]
:HL["/_next/static/chunks/701bfd7f976a1a7d.css","style"]
:HL["/_next/static/chunks/9506e893e1cc9117.css","style"]
:HL["/_next/static/chunks/0781faae427c77ef.css","style"]
:HL["/_next/static/media/1b99372b3eaef0c8-s.p.758e15a8.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:T1118,(function(){
  try {
    var r = document.documentElement;

    // 1. Dark Mode initialization
    var savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      r.classList.add('dark');
    } else {
      r.classList.remove('dark');
    }

    // 2. Color Palette & Primary/Accent Color resolution
    var PRESETS = {
      default: { primary: '#465fff', accent: '#3641f5' },
      emerald: { primary: '#10b981', accent: '#059669' },
      purple: { primary: '#8b5cf6', accent: '#7c3aed' },
      rose: { primary: '#f43f5e', accent: '#e11d48' },
      amber: { primary: '#f59e0b', accent: '#d97706' },
      indigo: { primary: '#6366f1', accent: '#4f46e5' },
    };

    var cachedPalette = localStorage.getItem('branding_color_palette') || 'custom';
    var cachedPrimary = localStorage.getItem('branding_custom_primary');
    var cachedSecondary = localStorage.getItem('branding_custom_secondary');

    var primaryColor = cachedPrimary || (PRESETS[cachedPalette] ? PRESETS[cachedPalette].primary : '#289333');
    var accentColor = cachedSecondary || (PRESETS[cachedPalette] ? PRESETS[cachedPalette].accent : primaryColor);

    function hexToRgb(hex) {
      if (!hex || typeof hex !== 'string') return null;
      var c = hex.replace('#', '').trim();
      if (c.length === 3) c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
      if (c.length === 6) {
        return [parseInt(c.substring(0, 2), 16), parseInt(c.substring(2, 4), 16), parseInt(c.substring(4, 6), 16)];
      }
      return null;
    }

    function generateShades(hex) {
      var rgb = hexToRgb(hex);
      if (!rgb) return null;
      var rVal = rgb[0] / 255, gVal = rgb[1] / 255, bVal = rgb[2] / 255;
      var max = Math.max(rVal, gVal, bVal), min = Math.min(rVal, gVal, bVal);
      var h = 0, s = 0, l = (max + min) / 2;
      if (max !== min) {
        var d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case rVal: h = (gVal - bVal) / d + (gVal < bVal ? 6 : 0); break;
          case gVal: h = (bVal - rVal) / d + 2; break;
          case bVal: h = (rVal - gVal) / d + 4; break;
        }
        h /= 6;
      }
      var hDeg = Math.round(h * 360), sPct = Math.round(s * 100);
      function hslToHex(hue, sat, lum) {
        lum /= 100;
        var a = (sat * Math.min(lum, 1 - lum)) / 100;
        var f = function(n) {
          var k = (n + hue / 30) % 12;
          var color = lum - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
          return Math.round(255 * color).toString(16).padStart(2, '0');
        };
        return '#' + f(0) + f(8) + f(4);
      }
      return {
        '25': hslToHex(hDeg, Math.min(sPct, 95), 98),
        '50': hslToHex(hDeg, Math.min(sPct, 95), 96),
        '100': hslToHex(hDeg, Math.min(sPct, 90), 91),
        '200': hslToHex(hDeg, Math.min(sPct, 85), 82),
        '300': hslToHex(hDeg, Math.min(sPct, 80), 71),
        '400': hslToHex(hDeg, Math.min(sPct, 75), 60),
        '500': hex,
        '600': hslToHex(hDeg, Math.min(sPct + 5, 100), 44),
        '700': hslToHex(hDeg, Math.min(sPct + 10, 100), 35),
        '800': hslToHex(hDeg, Math.min(sPct + 10, 100), 27),
        '900': hslToHex(hDeg, Math.min(sPct + 10, 100), 20),
        '950': hslToHex(hDeg, Math.min(sPct + 15, 100), 12),
      };
    }

    var shades = generateShades(primaryColor);
    if (shades) {
      Object.keys(shades).forEach(function(k) {
        r.style.setProperty('--color-brand-' + k, shades[k]);
      });
    }

    var rgb = hexToRgb(primaryColor);
    r.style.setProperty('--color-primary', primaryColor);
    if (rgb) r.style.setProperty('--color-primary-rgb', rgb.join(','));
    r.style.setProperty('--color-accent', accentColor);

    // 3. Canvas light & dark background colors
    var cLight = localStorage.getItem('branding_canvas_light') || '#f8fafc';
    var cDark = localStorage.getItem('branding_canvas_dark') || '#131127';
    r.style.setProperty('--color-canvas-light', cLight);
    r.style.setProperty('--color-canvas-dark', cDark);

    // 4. Custom font
    var cFont = localStorage.getItem('branding_font_family') || 'Vazirmatn';
    r.style.setProperty('--font-active', "'" + cFont + "', var(--font-outfit), Vazirmatn, Tahoma, sans-serif");
  } catch (e) {}
})();0:{"P":null,"b":"L6SxtE3YhqegVhZ12JYMn","c":["","basic-tables"],"q":"","i":false,"f":[[["",{"children":["(admin)",{"children":["(others-pages)",{"children":["(tables)",{"children":["basic-tables",{"children":["__PAGE__",{}]}]}]}]}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/701bfd7f976a1a7d.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/9506e893e1cc9117.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","2",{"rel":"stylesheet","href":"/_next/static/chunks/0781faae427c77ef.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/876ef404b65a90b7.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/c36f02d122d45be2.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"fa","dir":"rtl","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],{"children":["$L4",{"children":["$L5",{"children":["$L6",{"children":["$L7",{"children":["$L8",{},null,false,false]},null,false,false]},null,false,false]},null,false,false]},null,false,false]},null,false,false],"$L9",false]],"m":"$undefined","G":["$a",[]],"S":true}
b:I[83773,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"LanguageProvider"]
c:I[45993,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"BrandingProvider"]
d:I[9876,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"ThemeProvider"]
e:I[70689,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"AuthProvider"]
f:I[46208,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"SidebarProvider"]
10:I[44941,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"default"]
11:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
12:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
13:I[5500,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/8f6df9cd6e506907.js","/_next/static/chunks/8103a4fa4df1e2dd.js","/_next/static/chunks/a0228a82599e28b7.js"],"Image"]
14:I[22016,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/b4872826d9ffb447.js"],""]
15:I[72995,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js"],"LanguageToggleButton"]
16:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ClientSegmentRoot"]
17:I[31926,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/8f6df9cd6e506907.js","/_next/static/chunks/8103a4fa4df1e2dd.js"],"default"]
19:I[10728,["/_next/static/chunks/876ef404b65a90b7.js","/_next/static/chunks/c36f02d122d45be2.js","/_next/static/chunks/8f6df9cd6e506907.js","/_next/static/chunks/8103a4fa4df1e2dd.js","/_next/static/chunks/a0228a82599e28b7.js"],"default"]
21:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ViewportBoundary"]
23:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"MetadataBoundary"]
24:"$Sreact.suspense"
3:["$","body",null,{"className":"outfit_43d50961-module__KOAtAG__className text-slate-800 dark:text-gray-100 min-h-screen","suppressHydrationWarning":true,"children":["$","$Lb",null,{"children":["$","$Lc",null,{"children":["$","$Ld",null,{"children":["$","$Le",null,{"children":["$","$Lf",null,{"children":[["$","$L10",null,{}],["$","$L11",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L12",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"relative flex flex-col items-center justify-center min-h-screen p-6 overflow-hidden z-1","children":[[["$","div",null,{"className":"absolute right-0 top-0 -z-1 w-full max-w-[250px] xl:max-w-[450px]","children":["$","$L13",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}],["$","div",null,{"className":"absolute bottom-0 left-0 -z-1 w-full max-w-[250px] rotate-180 xl:max-w-[450px]","children":["$","$L13",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}]],["$","div",null,{"className":"mx-auto w-full max-w-[242px] text-center sm:max-w-[472px]","children":[["$","h1",null,{"className":"mb-8 font-bold text-gray-800 text-title-md dark:text-white/90 xl:text-title-2xl","children":"ERROR"}],["$","$L13",null,{"src":"/images/error/404.svg","alt":"404","className":"dark:hidden","width":472,"height":152}],["$","$L13",null,{"src":"/images/error/404-dark.svg","alt":"404","className":"hidden dark:block","width":472,"height":152}],["$","p",null,{"className":"mt-10 mb-6 text-base text-gray-700 dark:text-gray-400 sm:text-lg","children":"We can’t seem to find the page you are looking for!"}],["$","$L14",null,{"href":"/","className":"inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-5 py-3.5 text-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200","children":"Back to Home Page"}]]}],["$","p",null,{"className":"absolute text-sm text-center text-gray-500 -translate-x-1/2 bottom-6 left-1/2 dark:text-gray-400","children":["© ",2026," - امین وصال"]}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L15",null,{}]]}]}]}]}]}]}]
4:["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/8f6df9cd6e506907.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/8103a4fa4df1e2dd.js","async":true,"nonce":"$undefined"}]],["$","$L16",null,{"Component":"$17","slots":{"children":["$","$L11",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L12",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"relative flex flex-col items-center justify-center min-h-screen p-6 overflow-hidden z-1","children":[[["$","div",null,{"className":"absolute right-0 top-0 -z-1 w-full max-w-[250px] xl:max-w-[450px]","children":["$","$L13",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}],["$","div",null,{"className":"absolute bottom-0 left-0 -z-1 w-full max-w-[250px] rotate-180 xl:max-w-[450px]","children":["$","$L13",null,{"width":540,"height":254,"src":"/images/shape/grid-01.svg","alt":"grid"}]}]],["$","div",null,{"className":"mx-auto w-full max-w-[242px] text-center sm:max-w-[472px]","children":[["$","h1",null,{"className":"mb-8 font-bold text-gray-800 text-title-md dark:text-white/90 xl:text-title-2xl","children":"ERROR"}],["$","$L13",null,{"src":"/images/error/404.svg","alt":"404","className":"dark:hidden","width":472,"height":152}],["$","$L13",null,{"src":"/images/error/404-dark.svg","alt":"404","className":"hidden dark:block","width":472,"height":152}],["$","p",null,{"className":"mt-10 mb-6 text-base text-gray-700 dark:text-gray-400 sm:text-lg","children":"We can’t seem to find the page you are looking for!"}],["$","$L14",null,{"href":"/","className":"inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-5 py-3.5 text-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200","children":"Back to Home Page"}]]}],["$","p",null,{"className":"absolute text-sm text-center text-gray-500 -translate-x-1/2 bottom-6 left-1/2 dark:text-gray-400","children":["© ",2026," - امین وصال"]}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]},"serverProvidedParams":{"params":{},"promises":["$@18"]}}]]}]
5:["$","$1","c",{"children":[null,["$","$L11",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L12",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
6:["$","$1","c",{"children":[null,["$","$L11",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L12",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
7:["$","$1","c",{"children":[null,["$","$L11",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L12",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
8:["$","$1","c",{"children":[["$","div",null,{"children":[["$","$L19",null,{"pageTitle":"Basic Table"}],["$","div",null,{"className":"space-y-6","children":["$","div",null,{"className":"relative overflow-hidden rounded-2xl border border-slate-200/90 hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700 bg-white dark:bg-white/[0.03] shadow-soft hover:shadow-soft-hover transition-all duration-200 before:absolute before:top-0 before:inset-x-0 before:h-1 before:bg-gradient-to-r before:from-[var(--color-primary)] before:to-[var(--color-accent)] ","children":[["$","div",null,{"className":"px-6 py-4.5 border-b border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40","children":[["$","h3",null,{"className":"text-base font-bold text-slate-900 dark:text-white","children":"Basic Table 1"}],""]}],["$","div",null,{"className":"p-4 sm:p-6","children":["$","div",null,{"className":"space-y-6","children":["$","div",null,{"className":"overflow-hidden rounded-xl border border-gray-200 bg-white dark:border-white/[0.05] dark:bg-white/[0.03]","children":["$","div",null,{"className":"max-w-full overflow-x-auto","children":["$","div",null,{"className":"min-w-[1102px]","children":["$","table",null,{"className":"min-w-full  undefined","children":[["$","thead",null,{"className":"border-b border-gray-100 dark:border-white/[0.05]","children":["$","tr",null,{"className":"$undefined","children":[["$","th",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400","children":"User"}],["$","th",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400","children":"Project Name"}],["$","th",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400","children":"Team"}],["$","th",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400","children":"Status"}],["$","th",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-3 font-medium text-gray-500 text-start text-theme-xs dark:text-gray-400","children":"Budget"}]]}]}],["$","tbody",null,{"className":"divide-y divide-gray-100 dark:divide-white/[0.05]","children":[["$","tr","1",{"className":"$undefined","children":[["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-4 sm:px-6 text-start","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"className":"w-10 h-10 overflow-hidden rounded-full","children":["$","$L13",null,{"width":40,"height":40,"src":"/images/user/user-17.jpg","alt":"Lindsey Curtis"}]}],["$","div",null,{"children":[["$","span",null,{"className":"block font-medium text-gray-800 text-theme-sm dark:text-white/90","children":"Lindsey Curtis"}],["$","span",null,{"className":"block text-gray-500 text-theme-xs dark:text-gray-400","children":"Web Designer"}]]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":"Agency Website"}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","div",null,{"className":"flex -space-x-2","children":[["$","div","0",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-22.jpg","alt":"Team member 1","className":"w-full"}]}],["$","div","1",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-23.jpg","alt":"Team member 2","className":"w-full"}]}],["$","div","2",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-24.jpg","alt":"Team member 3","className":"w-full"}]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","span",null,{"className":"inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-theme-xs bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-500","children":["$undefined","Active","$undefined"]}]}],"$L1a"]}],"$L1b","$L1c","$L1d","$L1e"]}]]}]}]}]}]}]}]]}]}]]}],["$L1f"],"$L20"]}]
9:["$","$1","h",{"children":[null,["$","$L21",null,{"children":"$L22"}],["$","div",null,{"hidden":true,"children":["$","$L23",null,{"children":["$","$24",null,{"name":"Next.Metadata","children":"$L25"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
26:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
1a:["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400","children":"3.9K"}]
1b:["$","tr","2",{"className":"$undefined","children":[["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-4 sm:px-6 text-start","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"className":"w-10 h-10 overflow-hidden rounded-full","children":["$","$L13",null,{"width":40,"height":40,"src":"/images/user/user-18.jpg","alt":"Kaiya George"}]}],["$","div",null,{"children":[["$","span",null,{"className":"block font-medium text-gray-800 text-theme-sm dark:text-white/90","children":"Kaiya George"}],["$","span",null,{"className":"block text-gray-500 text-theme-xs dark:text-gray-400","children":"Project Manager"}]]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":"Technology"}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","div",null,{"className":"flex -space-x-2","children":[["$","div","0",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-25.jpg","alt":"Team member 1","className":"w-full"}]}],["$","div","1",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-26.jpg","alt":"Team member 2","className":"w-full"}]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","span",null,{"className":"inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-theme-xs bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-orange-400","children":["$undefined","Pending","$undefined"]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400","children":"24.9K"}]]}]
1c:["$","tr","3",{"className":"$undefined","children":[["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-4 sm:px-6 text-start","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"className":"w-10 h-10 overflow-hidden rounded-full","children":["$","$L13",null,{"width":40,"height":40,"src":"/images/user/user-17.jpg","alt":"Zain Geidt"}]}],["$","div",null,{"children":[["$","span",null,{"className":"block font-medium text-gray-800 text-theme-sm dark:text-white/90","children":"Zain Geidt"}],["$","span",null,{"className":"block text-gray-500 text-theme-xs dark:text-gray-400","children":"Content Writing"}]]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":"Blog Writing"}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","div",null,{"className":"flex -space-x-2","children":[["$","div","0",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-27.jpg","alt":"Team member 1","className":"w-full"}]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","span",null,{"className":"inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-theme-xs bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-500","children":["$undefined","Active","$undefined"]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400","children":"12.7K"}]]}]
1d:["$","tr","4",{"className":"$undefined","children":[["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-4 sm:px-6 text-start","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"className":"w-10 h-10 overflow-hidden rounded-full","children":["$","$L13",null,{"width":40,"height":40,"src":"/images/user/user-20.jpg","alt":"Abram Schleifer"}]}],["$","div",null,{"children":[["$","span",null,{"className":"block font-medium text-gray-800 text-theme-sm dark:text-white/90","children":"Abram Schleifer"}],["$","span",null,{"className":"block text-gray-500 text-theme-xs dark:text-gray-400","children":"Digital Marketer"}]]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":"Social Media"}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","div",null,{"className":"flex -space-x-2","children":[["$","div","0",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-28.jpg","alt":"Team member 1","className":"w-full"}]}],["$","div","1",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-29.jpg","alt":"Team member 2","className":"w-full"}]}],["$","div","2",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-30.jpg","alt":"Team member 3","className":"w-full"}]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","span",null,{"className":"inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-theme-xs bg-error-50 text-error-600 dark:bg-error-500/15 dark:text-error-500","children":["$undefined","Cancel","$undefined"]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400","children":"2.8K"}]]}]
1e:["$","tr","5",{"className":"$undefined","children":[["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-5 py-4 sm:px-6 text-start","children":["$","div",null,{"className":"flex items-center gap-3","children":[["$","div",null,{"className":"w-10 h-10 overflow-hidden rounded-full","children":["$","$L13",null,{"width":40,"height":40,"src":"/images/user/user-21.jpg","alt":"Carla George"}]}],["$","div",null,{"children":[["$","span",null,{"className":"block font-medium text-gray-800 text-theme-sm dark:text-white/90","children":"Carla George"}],["$","span",null,{"className":"block text-gray-500 text-theme-xs dark:text-gray-400","children":"Front-end Developer"}]]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":"Website"}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","div",null,{"className":"flex -space-x-2","children":[["$","div","0",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-31.jpg","alt":"Team member 1","className":"w-full"}]}],["$","div","1",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-32.jpg","alt":"Team member 2","className":"w-full"}]}],["$","div","2",{"className":"w-6 h-6 overflow-hidden border-2 border-white rounded-full dark:border-gray-900","children":["$","$L13",null,{"width":24,"height":24,"src":"/images/user/user-33.jpg","alt":"Team member 3","className":"w-full"}]}]]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-start text-theme-sm dark:text-gray-400","children":["$","span",null,{"className":"inline-flex items-center px-2.5 py-0.5 justify-center gap-1 rounded-full font-medium text-theme-xs bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-500","children":["$undefined","Active","$undefined"]}]}],["$","td",null,{"onClick":"$undefined","title":"$undefined","className":" px-4 py-3 text-gray-500 text-theme-sm dark:text-gray-400","children":"4.5K"}]]}]
1f:["$","script","script-0",{"src":"/_next/static/chunks/a0228a82599e28b7.js","async":true,"nonce":"$undefined"}]
20:["$","$L26",null,{"children":["$","$24",null,{"name":"Next.MetadataOutlet","children":"$@27"}]}]
18:"$4:props:children:1:props:serverProvidedParams:params"
22:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
28:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"IconMark"]
25:[["$","title","0",{"children":"امین وصال"}],["$","meta","1",{"name":"description","content":"مرکز همسان‌گزینی و ازدواج دائم امین وصال قم"}],["$","link","2",{"rel":"shortcut icon","href":"/media/site_branding/favicons/favicon.png"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?favicon.ba4b60c1.ico","sizes":"640x640","type":"image/x-icon"}],["$","link","4",{"rel":"icon","href":"/media/site_branding/favicons/favicon.png"}],["$","link","5",{"rel":"apple-touch-icon","href":"/media/site_branding/favicons/favicon.png"}],["$","$L28","6",{}]]
27:null
